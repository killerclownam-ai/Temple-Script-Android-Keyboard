# Temple Script Keyboard — v0.4

Android IME project for the fictional Temple Script developed in this conversation.

## What is included
- QWERTY Temple Script layout using the established glyph artwork assets.
- Dark stone/black keys with gold borders.
- Numbers layer and symbols layer.
- Shift/caps control.
- Space, backspace, enter, and layer controls.
- Glyph artwork stored in `app/src/main/assets/glyphs/`.
- H and P fall back to their Latin reference because those two glyph artworks were not present in the supplied alphabet chart.

## Important behavior
The glyph images are artwork, not Unicode characters. The keyboard therefore commits the Latin transliteration (A–Z) while displaying the Temple Script glyphs. This is intentional and keeps the keyboard compatible with ordinary Android text fields.

## Build
Open the project in Android Studio or another Android Gradle IDE, allow Gradle to sync, then build the debug APK.

## Enable on Android
Settings → System/General management → Keyboard → On-screen keyboard/Keyboard list → enable **Temple Script Keyboard**, then select it as the current keyboard. Exact menu names vary by phone.

## Layout
Main: QWERTY Temple Script glyphs.
Bottom controls: `?123` numbers, `◐` symbols, `⇧` shift, `SPACE`, `⌫`, `↵`.
