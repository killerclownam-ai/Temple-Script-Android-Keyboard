package com.templescript.keyboard;

import android.content.Context;
import android.graphics.*;
import android.inputmethodservice.InputMethodService;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class TempleInputMethodService extends InputMethodService {
    private static final String[][] LETTER_ROWS = {
        {"Q","W","E","R","T","Y","U","I","O","P"},
        {"A","S","D","F","G","H","J","K","L"},
        {"Z","X","C","V","B","N","M"}
    };

    private static final String[][] SYMBOL_ROWS = {
        {"🔥","🌿","☠","☾","☀","✦","◆","◇","•","—"},
        {".",",","!","?","'","\"",";",":","(",")"},
        {"@","#","$","%","&","*","+","=","/","\\"}
    };

    private static final String[][] NUMBER_ROWS = {
        {"1","2","3","4","5","6","7","8","9","0"},
        {"-","_","(",")","[","]","{","}","<",">"},
        {"~","^","`","|","€","£","¥","°","§","©"}
    };

    @Override public View onCreateInputView() {
        TempleKeyboardView v = new TempleKeyboardView(this);
        v.setService(this);
        return v;
    }

    public void typeKey(String key) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        switch (key) {
            case "⌫": ic.deleteSurroundingText(1, 0); break;
            case "↵": ic.commitText("\n", 1); break;
            case "SPACE": ic.commitText(" ", 1); break;
            case "🔥": ic.commitText("[FIREBORN]", 1); break;
            case "🌿": ic.commitText("[LIFE]", 1); break;
            case "☠": ic.commitText("[DEATH]", 1); break;
            case "☾": ic.commitText("[MOON]", 1); break;
            case "☀": ic.commitText("[SUN]", 1); break;
            default: ic.commitText(key, 1);
        }
    }

    public static class TempleKeyboardView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Map<String, Bitmap> glyphs = new HashMap<>();
        private TempleInputMethodService service;

        private int mode = 0; // 0 letters, 1 symbols, 2 numbers
        private boolean shift = true;

        public TempleKeyboardView(Context c) {
            super(c);
            setBackgroundColor(Color.rgb(7,7,7));
            loadGlyphs(c);
        }

        void setService(TempleInputMethodService s) { service = s; }

        private void loadGlyphs(Context c) {
            String[] names = {
                "A","B","C","D","E","F","G","I","J","K","L","M",
                "N","O","Q","R","S","T","U","V","W","X","Y","Z"
            };
            for (String n : names) {
                try (InputStream in = c.getAssets().open("glyphs/" + n + ".png")) {
                    glyphs.put(n, BitmapFactory.decodeStream(in));
                } catch (Exception ignored) {}
            }
        }

        private String[][] activeRows() {
            if (mode == 1) return SYMBOL_ROWS;
            if (mode == 2) return NUMBER_ROWS;
            return LETTER_ROWS;
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            float top=21, gap=7;
            float rowH=Math.max(52,(h-122)/3f);

            text.setTextAlign(Paint.Align.CENTER);
            text.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            text.setTextSize(13);
            text.setColor(Color.rgb(224,176,72));
            String title = mode==0 ? "TEMPLE SCRIPT" : mode==1 ? "SYMBOLS" : "NUMBERS";
            c.drawText(title, w/2f, 14, text);

            String[][] rows = activeRows();
            for(int r=0;r<3;r++){
                float inset=r==1?w*.035f:r==2?w*.075f:0;
                float avail=w-2*inset-gap*(rows[r].length-1);
                float kw=avail/rows[r].length;
                for(int i=0;i<rows[r].length;i++){
                    float x=inset+i*(kw+gap), y=top+r*(rowH+gap);
                    drawKey(c, rows[r][i], x,y,kw,rowH);
                }
            }

            float by=top+3*(rowH+gap);
            drawControl(c,"?123",0,by,w*.16f,58);
            drawControl(c,"◐",w*.17f,by,w*.16f,58);
            drawControl(c,shift && mode==0?"⇧":"✦",w*.34f,by,w*.17f,58);
            drawControl(c,"SPACE",w*.52f,by,w*.17f,58);
            drawControl(c,"⌫",w*.70f,by,w*.145f,58);
            drawControl(c,"↵",w*.845f,by,w*.155f,58);
        }

        private void drawKey(Canvas c,String key,float x,float y,float w,float h){
            fill.setColor(Color.rgb(20,20,20));
            c.drawRoundRect(x+1,y+1,x+w-1,y+h-1,10,10,fill);
            line.setColor(Color.rgb(126,91,35));
            line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(1.5f);
            c.drawRoundRect(x+1,y+1,x+w-1,y+h-1,10,10,line);

            if(mode==0 && glyphs.containsKey(key)){
                Bitmap b=glyphs.get(key);
                float maxW=w*.54f,maxH=h*.62f;
                float scale=Math.min(maxW/b.getWidth(),maxH/b.getHeight());
                float dw=b.getWidth()*scale,dh=b.getHeight()*scale;
                RectF d=new RectF(x+(w-dw)/2,y+(h-dh)/2-2,x+(w+dw)/2,y+(h+dh)/2-2);
                c.drawBitmap(b,null,d,new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG));
                text.setColor(Color.rgb(125,125,125)); text.setTextSize(8);
                c.drawText(key,x+w/2,y+h-5,text);
            } else {
                text.setColor(Color.rgb(242,190,78));
                text.setTextSize(key.length()>2?16:23);
                text.setTypeface(Typeface.DEFAULT_BOLD);
                c.drawText(shift && mode==0 ? key.toUpperCase() : key.toLowerCase(),x+w/2,y+h/2+8,text);
            }
        }

        private void drawControl(Canvas c,String key,float x,float y,float w,float h){
            fill.setColor(Color.rgb(24,24,24));
            c.drawRoundRect(x+1,y+1,x+w-1,y+h-1,10,10,fill);
            line.setColor(Color.rgb(150,105,35));
            c.drawRoundRect(x+1,y+1,x+w-1,y+h-1,10,10,line);
            text.setColor(Color.rgb(245,195,80)); text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(key.equals("⇧")||key.equals("✦")?25:key.equals("SPACE")?11:17);
            c.drawText(key,x+w/2,y+h/2+6,text);
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP || service==null) return true;
            float w=getWidth(),h=getHeight(),top=21,gap=7;
            float rowH=Math.max(52,(h-122)/3f);
            float tx=e.getX(),ty=e.getY();

            String[][] rows=activeRows();
            for(int r=0;r<3;r++){
                float inset=r==1?w*.035f:r==2?w*.075f:0;
                float avail=w-2*inset-gap*(rows[r].length-1);
                float kw=avail/rows[r].length, yy=top+r*(rowH+gap);
                if(ty>=yy && ty<=yy+rowH){
                    int i=(int)((tx-inset)/(kw+gap));
                    if(i>=0 && i<rows[r].length){
                        float xx=inset+i*(kw+gap);
                        if(tx>=xx && tx<=xx+kw){ service.typeKey(rows[r][i]); performClick(); return true; }
                    }
                }
            }

            float by=top+3*(rowH+gap);
            if(ty>=by){
                if(tx<w*.16f){ mode=mode==2?0:2; invalidate(); }
                else if(tx<w*.33f){ mode=mode==1?0:1; invalidate(); }
                else if(tx<w*.51f){ shift=!shift; invalidate(); }
                else if(tx<w*.69f){ service.typeKey("SPACE"); }
                else if(tx<w*.845f){ service.typeKey("⌫"); }
                else service.typeKey("↵");
                performClick();
            }
            return true;
        }
    }
}
