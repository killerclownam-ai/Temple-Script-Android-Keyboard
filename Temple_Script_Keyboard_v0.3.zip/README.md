# Temple Script Android Keyboard — v0.3

v0.3 pushes the keyboard UI further.

Added:
- Dedicated Symbols layer
- Dedicated Numbers layer
- Quick layer switching from the bottom-left controls
- Five elemental/cycle buttons: Fireborn, Life, Death, Moon, Sun
- Punctuation and common symbols
- Temple glyph artwork on the letter layer
- Backspace, space, and enter
- Compact Temple Script header

Important:
The Temple glyphs in the supplied chart are custom artwork rather than Unicode characters. The keyboard therefore displays the glyphs while the text output remains transliteration/plain characters. The elemental buttons insert readable tags such as [FIREBORN] in v0.3.

H and P remain reserved because those glyphs were not visible in the supplied alphabet chart.

Building:
This folder is an Android Studio/Android IDE project. Build a debug APK with an Android Gradle environment, install it, then enable Temple Script Keyboard in Android keyboard settings.

Note: the current workspace does not include a Gradle wrapper or Android SDK, so an APK cannot be compiled directly here. The complete project source is packaged for building in an Android IDE.
